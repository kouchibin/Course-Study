import CPP.Absyn.*;

public class Interpreter {

    public void interpret(Program p) {
        throw new RuntimeException("Not yet an interpreter");
    }

}
