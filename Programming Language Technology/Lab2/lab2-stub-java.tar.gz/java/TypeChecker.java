import CPP.Absyn.*;

public class TypeChecker {

    public void typecheck(Program p) {
        throw new TypeException("Not yet a typechecker");
    }

}
